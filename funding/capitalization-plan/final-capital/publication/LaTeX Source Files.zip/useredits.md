Author Kevin Kawchak Edits 10Aug26-11Aug26:

01) Fixed cover page vertical spacing, and added "Goal: " to funding related boxes.
02) Fixed all table column widths.
03) Converted three line captions into two line captions.
04) Added missing reference links.
05) Fixed unconventional terms (programme, favours, etc.) to typical American clinical trial terms (program, favors, etc.).
06) Author read full 38 page document using text-to-speech.
07) Fixed capstyle.sty to make all DOI hyperlinks blue to match other hyperlink formatting.
08) Fixed single word lines.
10) Fixed All Diagrams manually, or used Gemini 3.1 Pro and Claude Opus 5 High for challenging tasks.
11) Used term "projected" instead of "estimated" regarding the $36,330 valuation.
12) Fixed several reference URLs.
13) Verified each reference web site manually.
14) Addressed document white space issues.
15) Removed extra \clearpage between paper sections.
16) Obtain DOI
17) Implement DOI 3x
  