Author Completed: 8/3/26-8/4/26

01) Table IDs and Captions Fixed
1 2 3 4 5 6 7 8 9 10 11 
12 13 14 15 16 17 18
02) Figure IDs and Captions Fixed
1 2 3 4 5 6 7 8 9 10 
11 12 13 14 15 16 17 18 19 20
03) Fixed Page 22 overflow
04) Fixed .sty to make DOIs, URLs show using prompt: "Fix .sty so that every doi shows up for articles, with a clickable doi link for each. Also make sure clickable links show up for other references."
05) Fixed and editted several URLs. All 21 references work now.
06) Checked Table and Figure References throughout body text (search Figure 1, Table 2, etc. in pdf body)
07) Merged 10 Applications and Paper PR
08) Fixed single word lines
09) Table Columns Fixed
10) Full Author Read
11) Fixed Figure X Shifts using the code template:
START DIAGRAM X SHIFT
\newlength{\DiagramXShift}
\setlength{\DiagramXShift}{1.5mm} 
\begin{appfloat}[!tb]
\begin{adjustwidth}
  {\DiagramXShift}
  {\dimexpr-\DiagramXShift\relax}
\begin{appfig}[plantuml-type / use case]
\end{appfig}
\end{adjustwidth}
\vspace{-0.7cm}
\figcaption{ }
\end{appfloat}
END DIAGRAM X SHIFT
12) AI: Table 1 and Table 2 accuracy fixed.
Prompt: Provide full code for Table 1 regarding figures and Table 2 regarding tables that accurately reflects correct positioning in the paper, correct section number, correct contents, correct source directory, and "The question it answers" for each respective Table 1 and Table 2. Be similarly concise as current code to avoid extra lines. 
13) Fixed Figures 1, 4, 5, 11 Arrow Overlaps.
14) Figures 9 headings and boxes fixed.
15) Figures 14 "OR" up, smaller boxes fixed.
16) Done: Obtain and Implement DOI 3x