Author Edits Completed 08/07/26:

01) Fixed Figure X Shifts using code template:
\usepackage{changepage}
START DIAGRAM X SHIFT
\newlength{\DiagramXShift}
\setlength{\DiagramXShift}{1.5mm} 
\begin{appfloat}[!tb]
\begin{adjustwidth}
  {\DiagramXShift}
  {\dimexpr-\DiagramXShift\relax}
\begin{appfig}[plantuml-type / use case]
\end{appfig}
\end{adjustwidth}
\vspace{-0.7cm}
\figcaption{ }
\end{appfloat}
END DIAGRAM X SHIFT
02) Added Figure and Table numbers to captions
03) Added corresponding Figure and Table numbers to corresponding body context
04) Table column widths fixed
05) Added Science: A New Golden Age pdf URL
06) Verified each URL manually
07) Fixed .sty so that every doi shows up for articles, with a clickable doi link for each; and clickable links show up for other references
08) Checked for single word lines
09) Fixed Figure 1 arrow text positioning and boxes
10) Fixed Figure 2 text overlap and box widths
11) Fixed Figure 3 double text line to single text line
12) Read Full 4 Pages
13) Read Email Message
14) Modified 14 deposited works to 14 relevant works
15) Added "Industry trial" to Figure 2
16) Sent Email Message
