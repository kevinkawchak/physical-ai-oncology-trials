Author Edits Completed: 8/5/26

01) Fixed Figure X Shifts using code template:
START DIAGRAM X SHIFT
\newlength{\DiagramXShift}
\setlength{\DiagramXShift}{1.5mm} 
\begin{appfloat}[!tb]
\begin{adjustwidth}
  {\DiagramXShift}
  {\dimexpr-\DiagramXShift\relax}
\begin{appfig}[plantuml-type / use case]
\end{appfig}
\end{adjustwidth}
\vspace{-0.7cm}
\figcaption{ }
\end{appfloat}
END DIAGRAM X SHIFT
02) Added Figure and Table numbers to captions
03) Added corresponding Figure and Table numbers to corresponding body context
04) Table column widths fixed
05) Added Science: A New Golden Age pdf URL
06) Verified each URL manually
07) Full 4 Page Author Read
08) Fixed .sty so that every doi shows up for articles, with a clickable doi link for each; and clickable links show up for other references
09) Fixed single word lines
10) Fixed Figure 1 arrow lengths and positioning
11) Reformated Figure 3 box and line arrangements
12) Read 4 Pages
13) Read Email Message
14) Sent Email Message