Author Edits Completed 08/08/26:
 
01) Fixed Figure X Shifts using code template:
\usepackage{changepage}
START DIAGRAM X SHIFT
\newlength{\DiagramXShift}
\setlength{\DiagramXShift}{1.5mm} 
\begin{appfloat}[!tb]
\begin{adjustwidth}
  {\DiagramXShift}
  {\dimexpr-\DiagramXShift\relax}
\begin{appfig}[plantuml-type / use case]
\end{appfig}
\end{adjustwidth}
\vspace{-0.7cm}
\figcaption{ }
\end{appfloat}
END DIAGRAM X SHIFT
02) Added Figure and Table numbers to captions
03) Added corresponding Figure and Table numbers to corresponding body context
04) Table column widths fixed
05) Added Science: A New Golden Age and author Daraxonrasib Efficient LLM Trial Simulations URLs
06) Verified each URL manually
07) Fixed .sty so that every doi shows up for articles, with a clickable doi link for each; and clickable links show up for other references
08) Checked for single word lines
09) Fixed Figure 1 extra white spacing, and lowered a prominent arrow's curvature
10) Fixed Figure 3 arrow connectivities, number of lines per box, and additional line formatting 
11) Fixed cover page vertical spacing issues and improved line formatting
12) Modified 14 "deposited" works to 14 "relevant" works
13) Corrected term "estimated" to "projected" regarding $36,330 valuation
14) Read Full 4 Pages
15) Read Email Message
16) Sent Email Message

